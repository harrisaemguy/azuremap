(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
  typeof define === 'function' && define.amd ? define(['exports'], factory) :
  (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory((global.dc = global.dc || {}, global.dc.google_map = {})));
})(this, (function (exports) { 'use strict';

  function getAfFieldId(afField) {
    return afField.jsonModel.id || afField.jsonModel.templateId;
  }

  function promise(cssSelector) {
    var visible = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
    return new Promise(function (resolve) {
      var checking = setInterval(function () {
        $(cssSelector).length;

        if (visible && $(cssSelector).is(':visible') || !visible && $(cssSelector).length > 0) {
          clearInterval(checking);
          resolve(true);
        }
      }, 5);
    });
  }
  var cdnPromises = new Map(); // promise load once for all invoker

  function CDN_inHead(_ref4) {
    var _ref4$type = _ref4.type,
        type = _ref4$type === void 0 ? 'text/javascript' : _ref4$type,
        href = _ref4.href,
        src = _ref4.src;
    var key = 'text/css' === type ? href : src;

    if (key && cdnPromises.get(key)) {
      return cdnPromises.get(key);
    } else if ('text/css' === type && href) {
      var prom = new Promise(function (resolve) {
        var link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = href;
        link.type = type;
        document.head.appendChild(link);
        resolve({});
      });
      cdnPromises.set(href, prom);
      return prom;
    } else if ('text/javascript' === type && src) {
      var _prom = new Promise(function (resolve) {
        var script = document.createElement('script');
        script.type = type;

        script.onload = function () {
          resolve({});
        };

        script.src = src;
        document.head.appendChild(script);
      });

      cdnPromises.set(src, _prom);
      return _prom;
    }
  }

  var loadgoogleApi = function loadgoogleApi() {
    var polyfill = CDN_inHead({
      src: 'https://polyfill.io/v3/polyfill.min.js?features=default'
    });
    var mapApi = CDN_inHead({
      src: 'https://maps.googleapis.com/maps/api/js?libraries=places&key=AIzaSyBFQ9XxBmubeQOnWp4o3_Lp2lhFCQQTukU'
    });
    return [polyfill, mapApi];
  }; //used by afFld.initialize
  //assumption: AEM has sibling inputs: css=placeName, _LINE1, _CITY, _PROV, _PCODE, _CO, _STATE, _ZIP


  function init(thisInput) {
    var showMap = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
    var searchBoxId = getAfFieldId(thisInput);
    var parentPanel = thisInput.parent;
    Promise.all(loadgoogleApi()).then(function () {
      // when textbox available, append mapDiv
      promise('#' + searchBoxId).then(function () {
        var map_id = searchBoxId + '_map';
        var mapDiv = $('<div>', {
          id: map_id,
          "class": "mapDiv ".concat(showMap ? 'showMap' : 'hideMap')
        });
        $('#' + searchBoxId + ' input').after(mapDiv);
        var searchInputId = $("#".concat(searchBoxId, " input")).attr('id'); // when mapDiv available, load map

        promise('#' + map_id).then(function () {
          var map = new google.maps.Map(document.getElementById(map_id), {
            center: {
              lat: 45.424721,
              lng: -75.695
            },
            fullscreenControl: false,
            zoom: 13,
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            mapTypeControl: false,
            zoomControl: false,
            scaleControl: false,
            streetViewControl: false
          }); // auto center the map to your location
          // location service is available
          //map.setCenter(yourLoc);

          map.addListener('click', function (mapsMouseEvent) {
            mapsMouseEvent.stop(); // stop infowindow

            populateByLatLng(map, mapsMouseEvent.latLng.toJSON(), parentPanel);
          });
          var inputBox = document.getElementById(searchInputId);
          var searchBox = new google.maps.places.SearchBox(inputBox); // Bias the SearchBox results towards current map's viewport.

          map.addListener('bounds_changed', function () {
            searchBox.setBounds(map.getBounds());
          });
          var markers = [];
          searchBox.addListener('places_changed', function () {
            var places = searchBox.getPlaces();

            if (places.length == 0) {
              return;
            } // Clear out the old markers.


            markers.forEach(function (marker) {
              marker.setMap(null);
            });
            markers = []; // For each place, get the icon, name and location.

            var bounds = new google.maps.LatLngBounds();
            var labels = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
            places.forEach(function (place, idx) {
              if (!place.geometry || !place.geometry.location) {
                return;
              }

              var icon = {
                url: place.icon,
                size: new google.maps.Size(71, 71),
                origin: new google.maps.Point(0, 0),
                anchor: new google.maps.Point(17, 34),
                scaledSize: new google.maps.Size(25, 25)
              }; // Create a marker for each place.

              var marker = new google.maps.Marker({
                map: map,
                icon: icon,
                title: place.name,
                label: labels[idx % labels.length],
                position: place.geometry.location
              });
              marker.addListener('click', function () {
                map.setCenter(this.getPosition()); // console.log(this.getPosition().toJSON());

                populateByLatLng(map, this.getPosition().toJSON(), parentPanel, place.name);
              });
              markers.push(marker);

              if (place.geometry.viewport) {
                // Only geocodes have viewport.
                bounds.union(place.geometry.viewport);
              } else {
                bounds.extend(place.geometry.location);
              }
            });
            map.fitBounds(bounds);

            if (places.length == 1) {
              // populate address
              populateByLatLng(map, places[0].geometry.location.toJSON(), parentPanel, places[0].name);
            }
          });
        });
      });
    });
  }

  function populateByLatLng(map, latlng, mapPanel, placeName) {
    var geocoder = new google.maps.Geocoder();
    var service = new google.maps.places.PlacesService(map);
    geocoder.geocode({
      location: latlng
    }, function (results, status) {
      if (status === 'OK') {
        if (results[0]) {
          // console.dir(results[0]);
          getPlaceNameById(service, results[0].place_id, mapPanel, placeName);
        } else {
          window.alert('No results found');
        }
      } else {
        window.alert('Geocoder failed due to: ' + status);
      }
    });
  }

  function getPlaceNameById(service, placeId, mapPanel, placeName) {
    var request = {
      placeId: placeId,
      fields: ['name', 'geometry', 'address_component']
    };
    service.getDetails(request, function (place, status) {
      if (status === google.maps.places.PlacesServiceStatus.OK && place && place.geometry && place.geometry.location) {
        // refill
        var addressResult = {
          street_number: '',
          route: '',
          locality: '',
          sublocality_level_1: '',
          administrative_area_level_1: '',
          country: '',
          postal_code: ''
        }; // console.dir(place.address_components);

        place.address_components.forEach(function (component, index) {
          var addressType = component.types[0];

          if (addressResult.hasOwnProperty(addressType) && component.long_name) {
            addressResult[addressType] = component.long_name;
          }
        }); //console.log(addressResult);

        mapPanel.items.forEach(function (item) {
          if (placeName && item.cssClassName.includes('placeName')) {
            item.value = placeName;
          } else if (place.name && item.cssClassName.includes('placeName')) {
            item.value = place.name;
          }

          if (item.name.endsWith('_LINE1')) {
            item.value = addressResult.street_number + ' ' + addressResult.route;
          } else if (item.name.endsWith('_CO')) {
            var country = addressResult.country;

            if (country === 'United States') {
              // conforming to IRCC country list and required for zip code display logic
              country = 'United States of America';
            }

            item.value = country;
          } else if (item.name.endsWith('_CITY')) {
            item.value = addressResult.locality || addressResult.sublocality_level_1;
          }

          if ('Canada' === addressResult.country) {
            if (item.name.endsWith('_PROV')) {
              item.value = addressResult.administrative_area_level_1;
            }

            if (item.name.endsWith('_PCODE')) {
              item.value = addressResult.postal_code;
            }

            if (item.name.endsWith('_STATE') || item.name.endsWith('_ZIP')) {
              item.resetData();
            }
          } else if ('United States' === addressResult.country) {
            if (item.name.endsWith('_STATE')) {
              item.value = addressResult.administrative_area_level_1;
            }

            if (item.name.endsWith('_ZIP')) {
              item.value = addressResult.postal_code;
            }

            if (item.name.endsWith('_PROV') || item.name.endsWith('_PCODE')) {
              item.resetData();
            }
          } else {
            if (item.name.endsWith('_PROV') || item.name.endsWith('_PCODE')) {
              item.resetData();
            }

            if (item.name.endsWith('_STATE') || item.name.endsWith('_ZIP')) {
              item.resetData();
            }
          }
        });
      }
    });
  }

  exports.init = init;

}));
