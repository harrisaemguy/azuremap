(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
  typeof define === 'function' && define.amd ? define(['exports'], factory) :
  (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory((global.dc = global.dc || {}, global.dc.collapse = {})));
})(this, (function (exports) { 'use strict';

  function getAfFieldId(afField) {
    return afField.jsonModel.id || afField.jsonModel.templateId;
  }

  function promise(cssSelector) {
    var visible = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
    return new Promise(function (resolve) {
      var checking = setInterval(function () {
        $(cssSelector).length;

        if (visible && $(cssSelector).is(':visible') || !visible && $(cssSelector).length > 0) {
          clearInterval(checking);
          resolve(true);
        }
      }, 5);
    });
  }

  /*
  <div id="">
      <div class="card" id="">
          <a class="card-link" href="#collapseOne">
          Collapsible Group Item #1
          </a>
          <div id="" class="collapse" data-parent="#accordion">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
          </div>
      </div>
  </div>
  */
  //assume cardWrapper>card>(card-link, collapse)

  function apply2Textdraw(afFld) {
    var fldId = getAfFieldId(afFld);
    promise("#".concat(fldId, " .card")).then(function () {
      var cardWrapperId = "".concat(fldId, "_accordion");
      var data_parent = "#".concat(cardWrapperId);
      $("#".concat(fldId, " .card")).first().parent().attr('id', cardWrapperId);
      $("#".concat(fldId, " .card")).each(function (idx, ele) {
        var cardBodyId = "".concat(fldId, "_cardbody").concat(idx);
        $(ele).find('.collapse').attr('id', cardBodyId);
        $(ele).find('a.card-link').attr('data-target', '#' + cardBodyId).attr('href', '#' + cardBodyId).attr('data-parent', data_parent);
      });
      $("#".concat(cardWrapperId)).click(function (e) {
        if (e.target !== e.currentTarget && data_parent === $(e.target).data('parent')) {
          // clicked on one of my child toggler
          var target = $(e.target).data('target');
          $(".card:has([data-parent=\"".concat(data_parent, "\"]:not([data-target=\"").concat(target, "\"]))")).each(function (idx, card) {
            $(card).find('.collapse').removeClass('show');
          });
          $(".card:has([data-parent=\"".concat(data_parent, "\"][data-target=\"").concat(target, "\"])")).each(function (idx, card) {
            $(card).find('.collapse').toggleClass('show');
          });
          return false;
        }
      });
    });
  } //call this on repeatable panel's initialize
  //assume card (repeatable) has card-header and card-body

  function apply2Card(thisCard) {
    var btn_link = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
    var data_parent = '#' + getAfFieldId(thisCard.parent);
    var cardId = getAfFieldId(thisCard);
    var promise1 = promise('#' + cardId + ' .card-header');
    var promise2 = promise('#' + cardId + ' .card-body');
    Promise.all([promise1, promise2]).then(function (values) {
      var cardHeadId = $('#' + cardId + ' .card-header').attr('id');
      var cardBodyId = $('#' + cardId + ' .card-body').attr('id');

      if (btn_link) {
        var cardLink = $('<p><button class="btn btn-link text-left" type="button" data-target="#"></button></p>');
        cardLink.find('button').attr('data-target', '#' + cardBodyId).attr('data-parent', data_parent).text(thisCard.instanceIndex);
        cardLink.prependTo('#' + cardHeadId);
      } else {
        var _cardLink = $('<p><a class="card-link" href="#"></a></p>');

        _cardLink.find('a').attr('data-target', '#' + cardBodyId).attr('href', '#' + cardBodyId).attr('data-parent', data_parent).text(thisCard.instanceIndex);

        _cardLink.prependTo('#' + cardHeadId);
      }

      $('#' + cardBodyId).addClass('collapse');

      if ($("".concat(data_parent)).data('applyCollapse2Card') == undefined) {
        $("".concat(data_parent)).data('applyCollapse2Card', true); // only need to register once per parent

        $("".concat(data_parent)).click(function (e) {
          if (e.target !== e.currentTarget && data_parent === $(e.target).data('parent')) {
            // clicked on one of my child toggler
            var target = $(e.target).data('target');
            $(".card:has([data-parent=\"".concat(data_parent, "\"]:not([data-target=\"").concat(target, "\"]))")).each(function (idx, card) {
              $(card).find('.collapse').removeClass('show');
            });
            $(".card:has([data-parent=\"".concat(data_parent, "\"][data-target=\"").concat(target, "\"])")).each(function (idx, card) {
              $(card).find('.collapse').toggleClass('show');
            });
            return false;
          }
        });
      }
    });
  }

  exports.apply2Card = apply2Card;
  exports.apply2Textdraw = apply2Textdraw;

}));
