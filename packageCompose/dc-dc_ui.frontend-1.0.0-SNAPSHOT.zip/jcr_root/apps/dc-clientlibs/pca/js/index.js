(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
  typeof define === 'function' && define.amd ? define(['exports'], factory) :
  (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory((global.dc = global.dc || {}, global.dc.pca = {})));
})(this, (function (exports) { 'use strict';

  function getAfFieldId(afField) {
    return afField.jsonModel.id || afField.jsonModel.templateId;
  }

  function promise(cssSelector) {
    var visible = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
    return new Promise(function (resolve) {
      var checking = setInterval(function () {
        $(cssSelector).length;

        if (visible && $(cssSelector).is(':visible') || !visible && $(cssSelector).length > 0) {
          clearInterval(checking);
          resolve(true);
        }
      }, 5);
    });
  }
  var cdnPromises = new Map(); // promise load once for all invoker

  function CDN_inHead(_ref4) {
    var _ref4$type = _ref4.type,
        type = _ref4$type === void 0 ? 'text/javascript' : _ref4$type,
        href = _ref4.href,
        src = _ref4.src;
    var key = 'text/css' === type ? href : src;

    if (key && cdnPromises.get(key)) {
      return cdnPromises.get(key);
    } else if ('text/css' === type && href) {
      var prom = new Promise(function (resolve) {
        var link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = href;
        link.type = type;
        document.head.appendChild(link);
        resolve({});
      });
      cdnPromises.set(href, prom);
      return prom;
    } else if ('text/javascript' === type && src) {
      var _prom = new Promise(function (resolve) {
        var script = document.createElement('script');
        script.type = type;

        script.onload = function () {
          resolve({});
        };

        script.src = src;
        document.head.appendChild(script);
      });

      cdnPromises.set(src, _prom);
      return _prom;
    }
  }

  //<link rel="stylesheet" type="text/css" href="http://ws1.postescanada-canadapost.ca/css/addresscomplete-2.30.min.css?key=en29-dw13-hc17-hc98" />
  var options = {
    key: 'en29-dw13-hc17-hc98',
    //'EE31-DP19-AB89-YU99', //https://web.passport-online.apps.cic.gc.ca
    suppressAutocomplete: true,
    language: 'en'
  }; //promise load once for all invoker

  var loadPcaApi = function loadPcaApi() {
    var css1 = CDN_inHead({
      type: 'text/css',
      href: 'http://ws1.postescanada-canadapost.ca/css/addresscomplete-2.30.min.css'
    });
    var js1 = CDN_inHead({
      src: 'http://ws1.postescanada-canadapost.ca/js/addresscomplete-2.30.min.js'
    });
    return [css1, js1];
  }; //used by afFld.initialize
  // _CO:, _FIRSTLINE, _ADD1, _CITY, _PROV, _POSTAL, _PCODE, _STATE, _ZIP, _ZCODE


  function init(thisInput) {
    var searchBoxId = getAfFieldId(thisInput);
    var parentPanel = thisInput.parent;
    Promise.all(loadPcaApi()).then(function () {
      // when textbox available, append mapDiv
      promise('#' + searchBoxId).then(function () {
        var searchInputId = $("#".concat(searchBoxId, " input")).attr('id');
        var fields = [{
          element: searchInputId,
          field: '',
          mode: pca.fieldMode.DEFAULT
        }];
        new pca.Address(fields, options).listen('populate', function (address) {
          parentPanel.items.forEach(function (item) {
            if (item.name.endsWith('_FIRSTLINE') || item.name.endsWith('_ADD1')) {
              item.value = address.Line1;
            }

            if (item.name.endsWith('_CITY')) {
              item.value = address.City;
            }

            {
              if (item.name.endsWith('_PROV')) {
                item.value = address.ProvinceName;
              }

              if (item.name.endsWith('_POSTAL') || item.name.endsWith('_PCODE')) {
                item.value = address.PostalCode;
              }

              if (item.name.endsWith('_STATE') || item.name.endsWith('_ZIP') || item.name.endsWith('_ZCODE')) {
                item.resetData();
              }
            }
          });
        });
      });
    });
  }

  exports.init = init;

}));
