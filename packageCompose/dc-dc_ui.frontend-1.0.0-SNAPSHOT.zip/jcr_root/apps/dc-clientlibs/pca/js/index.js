(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
  typeof define === 'function' && define.amd ? define(['exports'], factory) :
  (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory((global.dc = global.dc || {}, global.dc.pca = {})));
})(this, (function (exports) { 'use strict';

  function getAfFieldId(afField) {
    return afField.jsonModel.id || afField.jsonModel.templateId;
  }

  function promise(cssSelector) {
    var visible = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
    return new Promise(function (resolve) {
      var checking = setInterval(function () {
        $(cssSelector).length;

        if (visible && $(cssSelector).is(':visible') || !visible && $(cssSelector).length > 0) {
          clearInterval(checking);
          resolve(true);
        }
      }, 5);
    });
  }

  //<link rel="stylesheet" type="text/css" href="http://ws1.postescanada-canadapost.ca/css/addresscomplete-2.30.min.css?key=en29-dw13-hc17-hc98" />
  var pcaPromise = undefined;
  var options = {
    key: 'en29-dw13-hc17-hc98',
    //'EE31-DP19-AB89-YU99', //https://web.passport-online.apps.cic.gc.ca
    suppressAutocomplete: true,
    language: 'en'
  }; // promise load once for all invoker

  var loadPCA = function loadPCA() {
    if (pcaPromise) {
      return pcaPromise;
    } else {
      pcaPromise = new Promise(function (resolve) {
        var link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = 'http://ws1.postescanada-canadapost.ca/css/addresscomplete-2.30.min.css';
        link.type = 'text/css';
        document.head.appendChild(link);
        var script = document.createElement('script');
        script.type = 'text/javascript';

        script.onload = function () {
          resolve({});
        };

        script.onreadystatechange = function () {
          // for IE
          resolve({});
        };

        script.src = 'http://ws1.postescanada-canadapost.ca/js/addresscomplete-2.30.min.js';
        document.head.appendChild(script);
      });
      return pcaPromise;
    }
  }; //used by afFld.initialize
  // _CO:, _FIRSTLINE, _ADD1, _CITY, _PROV, _POSTAL, _PCODE, _STATE, _ZIP, _ZCODE


  function init(thisInput) {
    var searchBoxId = getAfFieldId(thisInput);
    var parentPanel = thisInput.parent;
    loadPCA().then(function () {
      // when textbox available, append mapDiv
      promise('#' + searchBoxId).then(function () {
        var searchInputId = $("#".concat(searchBoxId, " input")).attr('id');
        var fields = [{
          element: searchInputId,
          field: '',
          mode: pca.fieldMode.DEFAULT
        }];
        new pca.Address(fields, options).listen('populate', function (address) {
          parentPanel.items.forEach(function (item) {
            if (item.name.endsWith('_FIRSTLINE') || item.name.endsWith('_ADD1')) {
              item.value = address.Line1;
            }

            if (item.name.endsWith('_CITY')) {
              item.value = address.City;
            }

            {
              if (item.name.endsWith('_PROV')) {
                item.value = address.ProvinceName;
              }

              if (item.name.endsWith('_POSTAL') || item.name.endsWith('_PCODE')) {
                item.value = address.PostalCode;
              }

              if (item.name.endsWith('_STATE') || item.name.endsWith('_ZIP') || item.name.endsWith('_ZCODE')) {
                item.resetData();
              }
            }
          });
        });
      });
    });
  }

  exports.init = init;

}));
